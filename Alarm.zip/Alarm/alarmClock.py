from tkinter import *
from tkinter.ttk import *
from time import *
from playsound import playsound


root = Tk()
root.geometry("500x500")
root.title('Clock')

def timeDisplay():
    string = strftime('%H:%M:%S %p')
    lbl.config(text = string)
    lbl.after(1000, timeDisplay)


def alarm():
    alarmTime = entry1.get()
    currentTime = strftime("%H:%M")
    print("Your alarm time is set to {}".format(alarmTime))
    while alarmTime != currentTime:
        currentTime = strftime("%H:%M")
        sleep(5)
    if alarmTime == currentTime:
        playsound("alarm.mp3")
        print("{}".format(entry2.get()))

        
        

frame1 = Frame(root)
frame1.pack()
frame1.config(height = 100, width = 100)


lbl = Label(root, font = ('calibri', 40, 'bold'), background ='black', foreground = 'blue')
lbl.pack(anchor = 'center')

canvas = Canvas(root, width = 500, height = 500)
canvas.pack()
    





label1= Label(canvas, text = 'Enter the Alarm time :', foreground='white',background='purple')
label1.pack()
canvas.create_window(100,140, window=label1)
entry1 = Entry(root)
canvas.create_window(300,140, window=entry1)

label2= Label(canvas,text = "Enter the Alarm message :", foreground="white",background="purple")
label2.pack()
canvas.create_window(100,240, window=label2)
entry2 = Entry(root)
canvas.create_window(300,240, window=entry2)

button = Button(canvas, text = "Set Alarm", command = alarm)
canvas.create_window(250,340, window=button)

label3= Label(frame1)
label3.pack()
timeDisplay()
mainloop()
