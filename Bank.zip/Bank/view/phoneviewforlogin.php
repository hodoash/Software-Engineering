<!-- <?php
//connect to the core file for general configuration
// require("../settings/core.php");
	
// 		//include the controller
// 		require('../controllers/logincontroller.php');

// 		   //return contacts
// 			$userlist = get_login_fxn();
        
//             $users_json=json_encode($userlist);
//             echo $users_json;

?>	
		 -->
