<?php
//Database credentials
define("DATABASE", "webtech_fall2019_");
define("SERVER", "cs.ashesi.edu.gh/");
define("USERNAME", "albert_hodo");
define("PASSWD", "albert_hodo");

?>
